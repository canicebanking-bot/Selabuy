const { json, db } = require('./_shared');
const { requireAdmin } = require('./_admin');
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed' });
  try {
    const auth = await requireAdmin(event);
    if (auth.error) return json(auth.status, { error: auth.error });
    const q = String(event.queryStringParameters?.q || '').trim().slice(0, 32);
    if (q.length < 2) return json(200, { users: [] });
    const safe = q.replace(/[%,()]/g, '');
    const accounts = await db(`dn_accounts?username_norm=ilike.*${encodeURIComponent(safe.toLowerCase())}*&is_active=eq.true&select=id,username,created_at&order=username.asc&limit=25`);
    if (!accounts.length) return json(200, { users: [] });
    const ids = accounts.map(a => a.id).join(',');
    const wallets = await db(`dn_wallets?account_id=in.(${ids})&select=account_id,balance_ngn`);
    const balances = Object.fromEntries(wallets.map(w => [w.account_id, Number(w.balance_ngn)]));
    return json(200, { users: accounts.map(a => ({ id: a.id, username: a.username, balance: balances[a.id] || 0, created_at: a.created_at })) });
  } catch (e) { return json(500, { error: 'Could not search accounts.' }); }
};
