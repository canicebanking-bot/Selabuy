const { json, db } = require('./_shared');
const { requireAdmin } = require('./_admin');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const auth = await requireAdmin(event);
    if (auth.error) return json(auth.status, { error: auth.error });
    const body = JSON.parse(event.body || '{}');
    const accountId = String(body.accountId || '');
    const amount = Number(body.amountNgn);
    const action = String(body.action || '');
    const reason = String(body.reason || '').trim();
    const requestId = String(body.requestId || '');
    if (!/^[0-9a-f-]{36}$/i.test(accountId) || !/^[0-9a-f-]{36}$/i.test(requestId)) return json(400, { error: 'Invalid account or request reference.' });
    if (!Number.isSafeInteger(amount) || amount < 1 || amount > 1000000000) return json(400, { error: 'Amount must be a whole naira amount between 1 and 1,000,000,000.' });
    if (!['credit','debit'].includes(action)) return json(400, { error: 'Choose credit or debit.' });
    if (reason.length < 3 || reason.length > 240) return json(400, { error: 'Enter a reason between 3 and 240 characters.' });
    const result = await db('rpc/dn_admin_adjust_wallet', { method: 'POST', body: JSON.stringify({ p_account_id: accountId, p_admin_id: auth.admin.id, p_amount_ngn: amount, p_action: action, p_reason: reason, p_request_id: requestId }) });
    return json(200, result);
  } catch (e) {
    const msg = String(e.message || e);
    if (/Insufficient balance/i.test(msg)) return json(409, { error: 'Insufficient balance for this deduction.' });
    if (/Wallet not found/i.test(msg)) return json(404, { error: 'User wallet not found.' });
    return json(400, { error: 'Wallet adjustment failed. No balance change was committed.' });
  }
};
