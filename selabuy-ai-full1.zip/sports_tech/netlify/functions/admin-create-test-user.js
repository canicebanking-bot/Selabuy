const { json, db, hashPassword } = require('./_shared');
const { requireAdmin } = require('./_admin');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const auth = await requireAdmin(event);
    if (auth.error) return json(auth.status, { error: auth.error });
    const body = JSON.parse(event.body || '{}');
    const username = String(body.username || '').trim();
    const password = String(body.password || '');
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return json(400, { error: 'Username must be 3–16 letters, numbers or underscores.' });
    if (password.length < 10 || password.length > 128) return json(400, { error: 'Password must be 10–128 characters.' });
    const rows = await db('dn_accounts?select=id,username', { method: 'POST', headers: { Prefer: 'return=representation' }, body: JSON.stringify({ username, username_norm: username.toLowerCase(), password_hash: hashPassword(password) }) });
    const account = rows[0];
    await db('dn_wallets', { method: 'POST', body: JSON.stringify({ account_id: account.id, balance_ngn: 0 }) });
    return json(201, { ok: true, user: account, balance: 0 });
  } catch (e) {
    if (String(e.message || e).includes('duplicate key')) return json(409, { error: 'That username already exists.' });
    return json(500, { error: 'Could not create test account.' });
  }
};
