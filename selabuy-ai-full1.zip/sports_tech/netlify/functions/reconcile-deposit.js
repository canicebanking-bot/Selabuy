/**
 * Reliable credit for fixed Paystack.shop links.
 * Credits only when Paystack has a matching successful transaction.
 * Works even if the return URL has no reference.
 * Idempotent — same Paystack reference cannot be credited twice.
 */

const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY || '';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

async function loadAppState(key) {
  const res = await fetch(URL + '/rest/v1/app_state?key=eq.' + encodeURIComponent(key) + '&select=data', {
    headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveAppState(key, data) {
  const res = await fetch(URL + '/rest/v1/app_state', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({ key, data, updated_at: new Date().toISOString() }),
  });
  return res.ok;
}

async function loadUser(username) {
  const res = await fetch(
    URL + '/rest/v1/users?username=eq.' + encodeURIComponent(String(username).toLowerCase()) + '&select=data',
    { headers: { apikey: KEY, Authorization: 'Bearer ' + KEY } }
  );
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveUser(user) {
  if (!user || !user.username) return false;
  const username = String(user.username).toLowerCase();
  user.updatedAt = Date.now();
  const res = await fetch(URL + '/rest/v1/users', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({ username, data: user, updated_at: new Date().toISOString() }),
  });
  return res.ok;
}

async function wasReferenceProcessed(reference) {
  const data = (await loadAppState('processed_refs')) || { refs: [] };
  const refs = Array.isArray(data.refs) ? data.refs : [];
  return refs.includes(String(reference));
}

async function markReferenceProcessed(reference) {
  const data = (await loadAppState('processed_refs')) || { refs: [] };
  let refs = Array.isArray(data.refs) ? data.refs.slice() : [];
  if (!refs.includes(String(reference))) {
    refs.unshift(String(reference));
    refs = refs.slice(0, 500);
    await saveAppState('processed_refs', { refs, updatedAt: Date.now() });
  }
}

async function findSuccessfulPaystackTx(amountNaira, preferredRef) {
  if (!PAYSTACK_SECRET) return null;
  const amountKobo = amountNaira * 100;
  try {
    // Prefer exact reference if we have one
    if (preferredRef) {
      const v = await fetch('https://api.paystack.co/transaction/verify/' + encodeURIComponent(preferredRef), {
        headers: { Authorization: 'Bearer ' + PAYSTACK_SECRET },
      });
      if (v.ok) {
        const j = await v.json();
        const d = j && j.data;
        if (d && d.status === 'success' && Math.round((Number(d.amount) || 0) / 100) === amountNaira) {
          return d;
        }
      }
    }
    // Fallback: recent successful transactions of this amount
    const list = await fetch(
      'https://api.paystack.co/transaction?status=success&amount=' + amountKobo + '&perPage=20',
      { headers: { Authorization: 'Bearer ' + PAYSTACK_SECRET } }
    );
    if (!list.ok) return null;
    const j = await list.json();
    const txs = (j && j.data) || [];
    const now = Date.now();
    for (const tx of txs) {
      if (!tx || tx.status !== 'success') continue;
      const amt = Math.round((Number(tx.amount) || 0) / 100);
      if (amt !== amountNaira) continue;
      const paidAt = tx.paid_at || tx.created_at;
      const t = paidAt ? new Date(paidAt).getTime() : 0;
      if (t && (now - t) > 3 * 60 * 60 * 1000) continue; // older than 3h
      if (await wasReferenceProcessed(tx.reference)) continue;
      return tx;
    }
  } catch (e) {}
  return null;
}

function creditUserObject(user, amount, reference) {
  user.balance = (user.balance || 0) + amount;
  user.history = user.history || [];
  if (user.history.some(h => h && (h.ref === reference || h.pendingId === reference))) {
    return { user, already: true };
  }
  user.history.unshift({
    id: Date.now(),
    type: 'deposit',
    amount,
    delta: amount,
    ref: reference,
    pendingId: reference,
    time: new Date().toISOString(),
    result: 'deposit',
    opponent: 'Deposit',
    wager: amount,
    p1Total: 0,
    p2Total: 0,
  });
  if (user.history.length > 300) user.history = user.history.slice(0, 300);
  user.updatedAt = Date.now();
  return { user, already: false };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const username = String(body.username || '').trim();
    const amountNaira = parseInt(body.amount, 10);
    const pendingId = String(body.pendingId || '').trim();
    const reference = String(body.reference || '').trim();

    if (!username || !amountNaira) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'username and amount required' }) };
    }

    const user = await loadUser(username);
    if (!user) {
      return { statusCode: 404, headers: cors, body: JSON.stringify({ error: 'user not found' }) };
    }

    // Already credited recently for this amount?
    const history = user.history || [];
    const already = history.find(h => {
      if (!h || h.type !== 'deposit') return false;
      if (reference && (h.ref === reference || h.pendingId === reference)) return true;
      if (Math.abs(h.amount || h.delta || 0) !== amountNaira) return false;
      const t = h.time ? new Date(h.time).getTime() : 0;
      return t && (Date.now() - t) < 15 * 60 * 1000;
    });
    if (already) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, already: true, credited: false, balance: user.balance || 0 }),
      };
    }

    // Must have a matching pending deposit
    const pendingData = (await loadAppState('pending_deposits')) || { items: [] };
    let items = Array.isArray(pendingData.items) ? pendingData.items.slice() : [];
    const now = Date.now();
    const match = items.find(p =>
      p &&
      p.status === 'pending' &&
      String(p.username || '').toLowerCase() === username.toLowerCase() &&
      parseInt(p.amount, 10) === amountNaira &&
      (!pendingId || p.id === pendingId) &&
      (now - (p.ts || 0)) < 3 * 60 * 60 * 1000
    );

    if (!match) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, already: false, credited: false, waiting: true, reason: 'no pending' }),
      };
    }

    // Confirm with Paystack that a successful payment of this amount exists
    const tx = await findSuccessfulPaystackTx(amountNaira, reference);
    if (!tx || !tx.reference) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, already: false, credited: false, waiting: true, reason: 'not paid' }),
      };
    }

    if (await wasReferenceProcessed(tx.reference)) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, already: true, credited: false, balance: user.balance || 0 }),
      };
    }

    const result = creditUserObject(user, amountNaira, tx.reference);
    if (!result.already) {
      await saveUser(result.user);
      await markReferenceProcessed(tx.reference);
    }

    items = items.filter(p => p && p.id !== match.id);
    await saveAppState('pending_deposits', { items, updatedAt: Date.now() });

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        ok: true,
        already: result.already,
        credited: !result.already,
        balance: result.user.balance,
        reference: tx.reference,
      }),
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
