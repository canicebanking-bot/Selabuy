/**
 * Public community chat
 * GET  → { messages: [...] }
 * POST { action: 'send', username, text }
 * POST { action: 'delete', id, isAdmin: true }
 */

const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

const MAX_MESSAGES = 120;
const MAX_TEXT = 240;

async function loadChat() {
  const res = await fetch(URL + '/rest/v1/app_state?key=eq.public_chat&select=data', {
    headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
  });
  if (!res.ok) return [];
  const rows = await res.json();
  const data = (rows && rows[0] && rows[0].data) || {};
  return Array.isArray(data.messages) ? data.messages : [];
}

async function saveChat(messages) {
  const res = await fetch(URL + '/rest/v1/app_state', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({
      key: 'public_chat',
      data: { messages, updatedAt: Date.now() },
      updated_at: new Date().toISOString(),
    }),
  });
  return res.ok;
}

function cleanText(t) {
  return String(t || '')
    .replace(/[\u0000-\u001F\u007F]/g, '')
    .trim()
    .slice(0, MAX_TEXT);
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }

  try {
    if (event.httpMethod === 'GET') {
      const messages = await loadChat();
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ messages: messages.slice(-MAX_MESSAGES) }),
      };
    }

    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
    }

    const body = JSON.parse(event.body || '{}');
    const action = String(body.action || '').trim();

    if (action === 'send') {
      const username = String(body.username || '').trim().slice(0, 32);
      const text = cleanText(body.text);
      if (!username || username.length < 2) {
        return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Login required' }) };
      }
      if (!text || text.length < 1) {
        return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Empty message' }) };
      }
      let messages = await loadChat();
      const msg = {
        id: 'c_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
        username,
        text,
        ts: Date.now(),
      };
      messages.push(msg);
      if (messages.length > MAX_MESSAGES) messages = messages.slice(-MAX_MESSAGES);
      await saveChat(messages);
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, message: msg, messages }),
      };
    }

    if (action === 'delete') {
      // Admin-only moderation (client must be in admin session; soft trust like other admin tools)
      if (!body.isAdmin) {
        return { statusCode: 403, headers: cors, body: JSON.stringify({ error: 'Admin only' }) };
      }
      const id = String(body.id || '').trim();
      if (!id) {
        return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'id required' }) };
      }
      let messages = await loadChat();
      const before = messages.length;
      messages = messages.filter(m => m && String(m.id) !== id);
      if (messages.length === before) {
        return { statusCode: 404, headers: cors, body: JSON.stringify({ error: 'not found' }) };
      }
      await saveChat(messages);
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, messages }),
      };
    }

    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'unknown action' }) };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
