const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

exports.handler = async () => {
  const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };
  try {
    const res = await fetch(URL + '/rest/v1/users?select=username,data', {
      headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
    });
    const text = await res.text();
    if (!res.ok) return { statusCode: 200, headers, body: JSON.stringify({ users: {}, error: text }) };
    const rows = JSON.parse(text);
    const users = {};
    (rows || []).forEach(row => {
      if (row && row.data && row.data.username) users[String(row.data.username).toLowerCase()] = row.data;
    });
    return { statusCode: 200, headers, body: JSON.stringify({ users }) };
  } catch (e) {
    return { statusCode: 200, headers, body: JSON.stringify({ users: {}, error: String(e.message || e) }) };
  }
};
