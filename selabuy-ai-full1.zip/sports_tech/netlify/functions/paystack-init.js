const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  if (!PAYSTACK_SECRET) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'PAYSTACK_SECRET_KEY not configured on server' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const amountNaira = parseInt(body.amount, 10);
    const username = String(body.username || '').trim();
    const email = String(body.email || '').trim().toLowerCase();

    if (!amountNaira || amountNaira < 1000) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Minimum deposit is ₦1,000' }) };
    }
    if (!username) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Username required' }) };
    }

    const amountKobo = amountNaira * 100;
    // Keep reference Paystack-safe (alphanumeric + underscore)
    const safeUser = username.replace(/[^a-zA-Z0-9]/g, '').slice(0, 24) || 'user';
    const ref = `DD_${safeUser}_${Date.now()}`;
    const callbackUrl = body.callback_url || '';

    const payload = {
      email: email || `${safeUser.toLowerCase()}@dicenaira.app`,
      amount: amountKobo,
      currency: 'NGN',
      reference: ref,
      metadata: {
        username,
        custom_fields: [
          { display_name: 'Username', variable_name: 'username', value: username }
        ]
      }
    };
    if (callbackUrl) payload.callback_url = callbackUrl;

    const res = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    const data = await res.json();
    if (!res.ok || !data.status) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: data.message || 'Paystack initialize failed' }) };
    }

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        authorization_url: data.data.authorization_url,
        reference: data.data.reference,
        amount: amountNaira
      })
    };
  } catch (err) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: err.message || 'Server error' }) };
  }
};
