const { json, db, readSession } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed' });
  try {
    const session = readSession(event);
    if (!session) return json(401, { error: 'Please log in again.' });
    const poolId = String(event.queryStringParameters?.poolId || '');
    if (!/^[0-9a-f-]{36}$/i.test(poolId)) return json(400, { error: 'Invalid pool.' });
    const member = await db(`dn_pool_positions?pool_id=eq.${poolId}&account_id=eq.${session.sub}&select=id&limit=1`);
    if (!member.length) return json(403, { error: 'You did not participate in this pool.' });
    const results = await db(`dn_pool_results?pool_id=eq.${poolId}&select=result,published_at&limit=1`);
    if (!results.length) return json(404, { error: 'Results are not available yet.' });
    const pool = await db(`dn_pool_positions?pool_id=eq.${poolId}&select=id,account_id,position_no,dice,score,created_at&order=position_no.asc`);
    const accounts = await db(`dn_accounts?select=id,username`);
    const names = Object.fromEntries(accounts.map(a => [a.id, a.username]));
    return json(200, { ...results[0].result, published_at: results[0].published_at, positions: pool.map(p => ({ ...p, username: names[p.account_id] || 'Player' })) });
  } catch { return json(500, { error: 'Could not load pool results.' }); }
};
