const { json, readSession } = require('./_shared');
const { settleReadyPool } = require('./_settlement');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const session = readSession(event);
    if (!session) return json(401, { error: 'Please log in again.' });
    const body = JSON.parse(event.body || '{}');
    const poolId = String(body.poolId || '');
    if (!/^[0-9a-f-]{36}$/i.test(poolId)) return json(400, { error: 'Invalid pool.' });
    const result = await settleReadyPool(poolId);
    if (!result) return json(409, { error: 'Pool is not ready to settle.' });
    return json(200, result);
  } catch (e) {
    return json(500, { error: 'Pool settlement failed. The pool remains available for a safe retry.' });
  }
};
