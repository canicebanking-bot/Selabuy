const { json, db, verifyPassword, issueSession, requireConfig } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    requireConfig();
    const body = JSON.parse(event.body || '{}');
    const username = String(body.username || '').trim().toLowerCase();
    const password = String(body.password || '');
    if (!username || !password) return json(400, { error: 'Username and password are required.' });
    const rows = await db(`dn_accounts?username_norm=eq.${encodeURIComponent(username)}&is_active=eq.true&select=id,username,password_hash&limit=1`);
    if (!rows.length || !verifyPassword(password, rows[0].password_hash)) return json(401, { error: 'Invalid username or password.' });
    const account = rows[0];
    const wallets = await db(`dn_wallets?account_id=eq.${account.id}&select=balance_ngn&limit=1`);
    return json(200, { ok: true, username: account.username, token: issueSession(account), balance: Number(wallets[0]?.balance_ngn || 0) });
  } catch (e) {
    return json(500, { error: 'Login is temporarily unavailable.' });
  }
};
