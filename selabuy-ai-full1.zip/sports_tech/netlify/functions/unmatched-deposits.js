/**
 * Admin: list / assign unmatched Paystack deposits
 * GET  → { items: [...] }
 * POST { action: 'assign', reference, username } → credit once
 * POST { action: 'dismiss', reference } → mark dismissed
 */

const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

async function loadAppState(key) {
  const res = await fetch(URL + '/rest/v1/app_state?key=eq.' + encodeURIComponent(key) + '&select=data', {
    headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveAppState(key, data) {
  const res = await fetch(URL + '/rest/v1/app_state', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({ key, data, updated_at: new Date().toISOString() }),
  });
  return res.ok;
}

async function loadUser(username) {
  const res = await fetch(
    URL + '/rest/v1/users?username=eq.' + encodeURIComponent(String(username).toLowerCase()) + '&select=data',
    { headers: { apikey: KEY, Authorization: 'Bearer ' + KEY } }
  );
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveUser(user) {
  if (!user || !user.username) return false;
  const username = String(user.username).toLowerCase();
  user.updatedAt = Date.now();
  const res = await fetch(URL + '/rest/v1/users', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({ username, data: user, updated_at: new Date().toISOString() }),
  });
  return res.ok;
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }

  try {
    if (event.httpMethod === 'GET') {
      const data = (await loadAppState('unmatched_deposits')) || { items: [] };
      const items = (Array.isArray(data.items) ? data.items : []).filter(
        x => x && (x.status === 'unmatched' || !x.status)
      );
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ items }),
      };
    }

    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
    }

    const body = JSON.parse(event.body || '{}');
    const action = String(body.action || '').trim();
    const reference = String(body.reference || '').trim();
    if (!reference) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'reference required' }) };
    }

    const umData = (await loadAppState('unmatched_deposits')) || { items: [] };
    let items = Array.isArray(umData.items) ? umData.items.slice() : [];
    const idx = items.findIndex(x => x && String(x.reference) === reference);
    if (idx < 0) {
      return { statusCode: 404, headers: cors, body: JSON.stringify({ error: 'not found' }) };
    }
    const row = items[idx];

    if (action === 'dismiss') {
      items[idx] = { ...row, status: 'dismissed', dismissedAt: Date.now() };
      await saveAppState('unmatched_deposits', { items, updatedAt: Date.now() });
      return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, dismissed: true }) };
    }

    if (action === 'assign') {
      const username = String(body.username || '').trim();
      if (!username) {
        return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'username required' }) };
      }
      const amount = parseInt(row.amount, 10);
      if (!amount || amount < 1000) {
        return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'invalid amount' }) };
      }

      // Global processed refs
      const proc = (await loadAppState('processed_deposits')) || { refs: [] };
      const refs = Array.isArray(proc.refs) ? proc.refs.slice() : [];
      if (refs.includes(reference)) {
        items[idx] = { ...row, status: 'assigned', assignedTo: username, assignedAt: Date.now() };
        await saveAppState('unmatched_deposits', { items, updatedAt: Date.now() });
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ ok: true, already: true, message: 'Already processed' }),
        };
      }

      const user = await loadUser(username);
      if (!user) {
        return { statusCode: 404, headers: cors, body: JSON.stringify({ error: 'user not found' }) };
      }
      if ((user.history || []).some(h => h && String(h.ref) === reference)) {
        items[idx] = { ...row, status: 'assigned', assignedTo: username, assignedAt: Date.now() };
        await saveAppState('unmatched_deposits', { items, updatedAt: Date.now() });
        return {
          statusCode: 200,
          headers: cors,
          body: JSON.stringify({ ok: true, already: true, balance: user.balance || 0 }),
        };
      }

      refs.push(reference);
      await saveAppState('processed_deposits', { refs: refs.slice(-500), updatedAt: Date.now() });

      user.balance = (user.balance || 0) + amount;
      user.history = user.history || [];
      user.history.unshift({
        id: Date.now(),
        type: 'deposit',
        amount,
        delta: amount,
        ref: reference,
        time: new Date().toISOString(),
        result: 'deposit',
        opponent: 'Deposit',
        wager: amount,
        p1Total: 0,
        p2Total: 0,
      });
      if (user.history.length > 300) user.history = user.history.slice(0, 300);
      user.updatedAt = Date.now();
      await saveUser(user);

      items[idx] = {
        ...row,
        status: 'assigned',
        assignedTo: username,
        assignedAt: Date.now(),
      };
      await saveAppState('unmatched_deposits', { items, updatedAt: Date.now() });

      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({
          ok: true,
          credited: true,
          username,
          amount,
          reference,
          balance: user.balance,
        }),
      };
    }

    return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'unknown action' }) };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
