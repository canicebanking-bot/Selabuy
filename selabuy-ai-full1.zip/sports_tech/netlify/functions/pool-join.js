const { json, db, readSession } = require('./_shared');
const { settleReadyPool } = require('./_settlement');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    const session = readSession(event);
    if (!session) return json(401, { error: 'Please log in again.' });
    const body = JSON.parse(event.body || '{}');
    const tier = String(body.tier || '');
    const entry = Number(body.entryNgn);
    const requestId = String(body.requestId || '');
    if (!/^[0-9a-f-]{36}$/i.test(requestId) || !['5x','10x','50x'].includes(tier) || !Number.isSafeInteger(entry) || entry < 1) return json(400, { error: 'Invalid pool selection.' });
    const joined = await db('rpc/dn_join_pool', { method: 'POST', body: JSON.stringify({ p_account_id: session.sub, p_tier: tier, p_entry_ngn: entry, p_request_id: requestId }) });
    let settlement = null;
    if (joined.status === 'ready' && joined.pool_id) {
      // Settle synchronously as soon as the final position is locked, so winners
      // do not wait for the next scheduled one-minute worker run.
      settlement = await settleReadyPool(joined.pool_id);
    }
    const wallets = await db(`dn_wallets?account_id=eq.${session.sub}&select=balance_ngn&limit=1`);
    return json(200, { ...joined, balance_ngn: Number(wallets[0]?.balance_ngn ?? joined.balance_ngn ?? 0), settlement });
  } catch (e) {
    const message = String(e.message || e);
    if (message.includes('Insufficient wallet')) return json(409, { error: 'Insufficient wallet balance.' });
    if (message.includes('Maximum positions')) return json(409, { error: 'Maximum positions reached in this pool.' });
    return json(500, { error: 'Could not complete this pool entry or settlement. Check your wallet and pool history before retrying.' });
  }
};
