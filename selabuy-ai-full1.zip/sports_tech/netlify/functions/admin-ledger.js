const { json, db } = require('./_shared');
const { requireAdmin } = require('./_admin');
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed' });
  try {
    const auth = await requireAdmin(event);
    if (auth.error) return json(auth.status, { error: auth.error });
    const accountId = String(event.queryStringParameters?.accountId || '');
    if (!/^[0-9a-f-]{36}$/i.test(accountId)) return json(400, { error: 'Invalid account.' });
    const rows = await db(`dn_wallet_ledger?account_id=eq.${encodeURIComponent(accountId)}&select=id,entry_type,amount_ngn,balance_after_ngn,details,created_at&order=created_at.desc&limit=100`);
    return json(200, { transactions: rows.map(r => ({ ...r, amount_ngn: Number(r.amount_ngn), balance_after_ngn: Number(r.balance_after_ngn) })) });
  } catch { return json(500, { error: 'Could not load transaction history.' }); }
};
