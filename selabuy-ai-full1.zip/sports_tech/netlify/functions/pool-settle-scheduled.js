const crypto = require('crypto');
const { db, requireConfig } = require('./_shared');
exports.config = { schedule: '* * * * *' };
exports.handler = async () => {
  try {
    requireConfig();
    const ready = await db('dn_pools?status=eq.ready&select=id&order=created_at.asc&limit=100');
    const outcomes = [];
    for (const pool of ready) {
      try {
        const positions = await db(`dn_pool_positions?pool_id=eq.${pool.id}&select=id`);
        const scores = positions.map(p => ({ position_id: p.id, dice: [crypto.randomInt(1,7), crypto.randomInt(1,7), crypto.randomInt(1,7)] }));
        const result = await db('rpc/dn_settle_pool', { method: 'POST', body: JSON.stringify({ p_pool_id: pool.id, p_scores: scores }) });
        outcomes.push({ poolId: pool.id, settled: true, result });
      } catch (error) {
        outcomes.push({ poolId: pool.id, settled: false, error: String(error.message || error) });
      }
    }
    return { statusCode: 200, body: JSON.stringify({ checked: ready.length, outcomes }) };
  } catch (error) {
    return { statusCode: 500, body: JSON.stringify({ error: String(error.message || error) }) };
  }
};
