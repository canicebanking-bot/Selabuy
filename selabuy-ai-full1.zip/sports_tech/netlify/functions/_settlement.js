const crypto = require('crypto');
const { db } = require('./_shared');

async function settleReadyPool(poolId) {
  const pools = await db(`dn_pools?id=eq.${poolId}&select=id,status`);
  if (!pools.length) throw new Error('Pool not found');
  if (pools[0].status === 'settled') {
    const done = await db(`dn_pool_results?pool_id=eq.${poolId}&select=result&limit=1`);
    return done[0]?.result || { pool_id: poolId, duplicate: true };
  }
  if (pools[0].status !== 'ready') return null;
  const positions = await db(`dn_pool_positions?pool_id=eq.${poolId}&select=id`);
  if (!positions.length) throw new Error('No pool positions');
  const scores = positions.map(position => ({
    position_id: position.id,
    dice: [crypto.randomInt(1, 7), crypto.randomInt(1, 7), crypto.randomInt(1, 7)]
  }));
  // The database RPC locks the pool and settles it in one transaction. If the
  // scheduled worker races this request, the second call receives the stored result.
  return db('rpc/dn_settle_pool', {
    method: 'POST',
    body: JSON.stringify({ p_pool_id: poolId, p_scores: scores })
  });
}

module.exports = { settleReadyPool };
