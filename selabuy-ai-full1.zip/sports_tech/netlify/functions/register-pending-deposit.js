const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

async function loadPending() {
  const res = await fetch(URL + '/rest/v1/app_state?key=eq.pending_deposits&select=data', {
    headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
  });
  if (!res.ok) return [];
  const rows = await res.json();
  const data = (rows && rows[0] && rows[0].data) || {};
  return Array.isArray(data.items) ? data.items : [];
}

async function savePending(items) {
  // Drop expired (> 3 hours) and already-credited entries
  const now = Date.now();
  const cleaned = (items || []).filter(p =>
    p && p.status === 'pending' && (now - (p.ts || 0)) < 3 * 60 * 60 * 1000
  ).slice(-200);

  const res = await fetch(URL + '/rest/v1/app_state', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({
      key: 'pending_deposits',
      data: { items: cleaned, updatedAt: now },
      updated_at: new Date().toISOString(),
    }),
  });
  return res.ok;
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const amount = parseInt(body.amount, 10);
    const username = String(body.username || '').trim();
    const id = String(body.id || ('pd_' + Date.now())).trim();
    const ts = body.ts || Date.now();

    if (!amount || amount < 1000) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Invalid amount' }) };
    }
    if (!username) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Username required' }) };
    }

    const items = await loadPending();
    items.push({
      id,
      amount,
      username,
      ts,
      status: 'pending',
    });
    await savePending(items);

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({ ok: true, id }),
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
