const { db, readSession } = require('./_shared');
async function requireAdmin(event) {
  const session = readSession(event);
  if (!session) return { error: 'Please log in again.', status: 401 };
  const rows = await db(`dn_accounts?id=eq.${encodeURIComponent(session.sub)}&is_active=eq.true&select=id,username,is_admin&limit=1`);
  if (!rows.length || rows[0].is_admin !== true) return { error: 'Administrator access required.', status: 403 };
  return { admin: rows[0] };
}
module.exports = { requireAdmin };
