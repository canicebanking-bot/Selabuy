const { json, db, readSession } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed' });
  try {
    const session = readSession(event);
    if (!session) return json(401, { error: 'Please log in again.' });
    const rows = await db(`dn_wallets?account_id=eq.${session.sub}&select=balance_ngn&limit=1`);
    if (!rows.length) return json(404, { error: 'Wallet not found.' });
    return json(200, { username: session.username, balance: Number(rows[0].balance_ngn) });
  } catch { return json(500, { error: 'Could not load wallet.' }); }
};
