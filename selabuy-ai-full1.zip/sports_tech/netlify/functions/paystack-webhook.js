/**
 * Paystack webhook — auto-credits user wallets when a fixed payment-page charge succeeds.
 *
 * Setup in Paystack Dashboard → Settings → API Keys & Webhooks:
 *   URL: https://YOUR-SITE/.netlify/functions/paystack-webhook
 *   Events: charge.success
 *
 * Matching strategy for fixed Paystack.shop links (no per-user reference):
 *   1. Prefer metadata.username if present
 *   2. Else match oldest pending deposit of the same amount (registered when user tapped Deposit)
 */

const crypto = require('crypto');

const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';
const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY || '';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type, x-paystack-signature',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function verifySignature(rawBody, signature) {
  // If no secret is configured, allow the webhook (so deposits are not blocked)
  if (!PAYSTACK_SECRET) return true;
  if (!signature) return false;
  const hash = crypto.createHmac('sha512', PAYSTACK_SECRET).update(rawBody).digest('hex');
  return hash === signature;
}

async function loadAppState(key) {
  const res = await fetch(URL + '/rest/v1/app_state?key=eq.' + encodeURIComponent(key) + '&select=data', {
    headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
  });
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveAppState(key, data) {
  const res = await fetch(URL + '/rest/v1/app_state', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({
      key,
      data,
      updated_at: new Date().toISOString(),
    }),
  });
  return res.ok;
}

async function loadUser(username) {
  const res = await fetch(
    URL + '/rest/v1/users?username=eq.' + encodeURIComponent(String(username).toLowerCase()) + '&select=data',
    { headers: { apikey: KEY, Authorization: 'Bearer ' + KEY } }
  );
  if (!res.ok) return null;
  const rows = await res.json();
  return (rows && rows[0] && rows[0].data) || null;
}

async function saveUser(user) {
  if (!user || !user.username) return false;
  const username = String(user.username).toLowerCase();
  user.updatedAt = Date.now();
  const res = await fetch(URL + '/rest/v1/users', {
    method: 'POST',
    headers: {
      apikey: KEY,
      Authorization: 'Bearer ' + KEY,
      'Content-Type': 'application/json',
      Prefer: 'resolution=merge-duplicates',
    },
    body: JSON.stringify({
      username,
      data: user,
      updated_at: new Date().toISOString(),
    }),
  });
  return res.ok;
}

async function wasReferenceProcessed(reference) {
  const data = (await loadAppState('processed_deposits')) || { refs: [] };
  return Array.isArray(data.refs) && data.refs.includes(reference);
}

async function markReferenceProcessed(reference) {
  const data = (await loadAppState('processed_deposits')) || { refs: [] };
  const refs = Array.isArray(data.refs) ? data.refs : [];
  if (!refs.includes(reference)) refs.push(reference);
  // Keep last 500 refs
  await saveAppState('processed_deposits', { refs: refs.slice(-500), updatedAt: Date.now() });
}

function creditUserObject(user, amount, reference) {
  user.balance = (user.balance || 0) + amount;
  user.history = user.history || [];
  // Skip if this reference already in history
  if (user.history.some(h => h.ref === reference)) {
    return { user, already: true };
  }
  user.history.unshift({
    id: Date.now(),
    type: 'deposit',
    amount,
    delta: amount,
    ref: reference,
    time: new Date().toISOString(),
    result: 'deposit',
    opponent: 'Deposit',
    wager: amount,
    p1Total: 0,
    p2Total: 0,
  });
  if (user.history.length > 300) user.history = user.history.slice(0, 300);
  user.updatedAt = Date.now();
  return { user, already: false };
}

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  const rawBody = event.body || '';
  const signature = (event.headers && (event.headers['x-paystack-signature'] || event.headers['X-Paystack-Signature'])) || '';

  // Verify signature when secret is configured (required in production)
  if (PAYSTACK_SECRET) {
    if (!verifySignature(rawBody, signature)) {
      return { statusCode: 401, headers: cors, body: JSON.stringify({ error: 'Invalid signature' }) };
    }
  }

  try {
    const payload = JSON.parse(rawBody || '{}');
    const eventName = payload.event || '';
    const tx = (payload.data || {});

    // Only handle successful charges
    if (eventName && eventName !== 'charge.success') {
      return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, ignored: eventName }) };
    }

    const status = tx.status || '';
    if (status && status !== 'success') {
      return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, ignored: status }) };
    }

    const reference = String(tx.reference || tx.id || '').trim();
    const amountNaira = Math.round((Number(tx.amount) || 0) / 100);

    if (!reference || !amountNaira || amountNaira < 1000) {
      return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, skipped: 'bad amount/ref' }) };
    }

    // Global idempotency on Paystack reference
    if (await wasReferenceProcessed(reference)) {
      return { statusCode: 200, headers: cors, body: JSON.stringify({ ok: true, duplicate: true }) };
    }

    // Resolve username: metadata first, then EXACT pending deposit (required for fixed links)
    let username = '';
    const meta = tx.metadata || {};
    if (meta.username) {
      username = String(meta.username).trim();
    } else if (Array.isArray(meta.custom_fields)) {
      const field = meta.custom_fields.find(f =>
        f && (f.variable_name === 'username' || f.display_name === 'Username')
      );
      if (field && field.value) username = String(field.value).trim();
    }

    let pendingMatch = null;
    const pendingData = (await loadAppState('pending_deposits')) || { items: [] };
    let items = Array.isArray(pendingData.items) ? pendingData.items.slice() : [];
    const now = Date.now();

    if (username) {
      pendingMatch = items.find(p =>
        p &&
        p.status === 'pending' &&
        String(p.username || '').toLowerCase() === username.toLowerCase() &&
        parseInt(p.amount, 10) === amountNaira &&
        (now - (p.ts || 0)) < 3 * 60 * 60 * 1000
      ) || null;
    } else {
      // Fixed Paystack.shop links: must have a pending row registered when user tapped Deposit
      const candidates = items
        .filter(p =>
          p &&
          p.status === 'pending' &&
          parseInt(p.amount, 10) === amountNaira &&
          (now - (p.ts || 0)) < 3 * 60 * 60 * 1000
        )
        .sort((a, b) => (a.ts || 0) - (b.ts || 0));
      pendingMatch = candidates[0] || null;
      if (pendingMatch) username = String(pendingMatch.username || '').trim();
    }

    // No pending + no metadata username → do NOT credit anyone; store for admin assignment
    if (!username || !pendingMatch) {
      try {
        const umData = (await loadAppState('unmatched_deposits')) || { items: [] };
        let umItems = Array.isArray(umData.items) ? umData.items.slice() : [];
        if (!umItems.some(x => x && String(x.reference) === reference)) {
          umItems.unshift({
            id: 'um_' + Date.now(),
            reference,
            amount: amountNaira,
            paidAt: tx.paid_at || tx.created_at || new Date().toISOString(),
            customerEmail: (tx.customer && tx.customer.email) || null,
            status: 'unmatched',
            ts: Date.now(),
          });
          umItems = umItems.slice(0, 200);
          await saveAppState('unmatched_deposits', { items: umItems, updatedAt: Date.now() });
        }
      } catch (e) {}
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({
          ok: true,
          unmatched: true,
          amount: amountNaira,
          reference,
          message: 'No matching pending deposit — saved for admin',
        }),
      };
    }

    // Claim reference before writing balance
    await markReferenceProcessed(reference);

    const user = await loadUser(username);
    if (!user) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, userMissing: true, username }),
      };
    }

    // Same ref already in history → never add again
    if ((user.history || []).some(h => h && String(h.ref) === reference)) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ ok: true, duplicate: true, username, balance: user.balance || 0 }),
      };
    }

    const result = creditUserObject(user, amountNaira, reference);
    if (!result.already) {
      await saveUser(result.user);
    }

    // Remove ONLY the matched pending row
    items = items.filter(p => p && p.id !== pendingMatch.id);
    await saveAppState('pending_deposits', { items, updatedAt: Date.now() });

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        ok: true,
        credited: !result.already,
        username,
        amount: amountNaira,
        reference,
        balance: result.user.balance,
      }),
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
