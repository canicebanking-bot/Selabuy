const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

exports.handler = async (event) => {
  const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers, body: '' };
  try {
    const body = JSON.parse(event.body || '{}');
    const user = body.user;
    if (!user || !user.username) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'username required' }) };
    }
    const username = String(user.username).toLowerCase();
    // Reject an older copy so a slow phone cannot overwrite a newer balance.
    const cur = await fetch(URL + '/rest/v1/users?username=eq.' + encodeURIComponent(username) + '&select=data', {
      headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
    });
    if (cur.ok) {
      const rows = await cur.json();
      const existing = rows && rows[0] && rows[0].data;
      if (existing && (existing.updatedAt || 0) > (user.updatedAt || 0)) {
        return { statusCode: 409, headers, body: JSON.stringify({ error: 'stale', user: existing }) };
      }
    }
    const res = await fetch(URL + '/rest/v1/users', {
      method: 'POST',
      headers: {
        apikey: KEY,
        Authorization: 'Bearer ' + KEY,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      },
      body: JSON.stringify({ username, data: user, updated_at: new Date().toISOString() }),
    });
    const text = await res.text();
    if (!res.ok) return { statusCode: 500, headers, body: JSON.stringify({ error: text }) };
    return { statusCode: 200, headers, body: JSON.stringify({ ok: true, username }) };
  } catch (e) {
    return { statusCode: 500, headers, body: JSON.stringify({ error: String(e.message || e) }) };
  }
};
