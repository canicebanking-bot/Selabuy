const URL = 'https://tznofqvhnajvxgqulqts.supabase.co';
const KEY = 'sb_publishable_vKz6fQTjR6V82cNVZ1ZKUQ_Daj-KNBt';

exports.handler = async () => {
  const headers = { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' };
  try {
    const res = await fetch(URL + '/rest/v1/app_state?key=eq.house&select=data', {
      headers: { apikey: KEY, Authorization: 'Bearer ' + KEY },
    });
    const text = await res.text();
    if (!res.ok) return { statusCode: 200, headers, body: JSON.stringify({ house: null, error: text }) };
    const rows = JSON.parse(text);
    const house = (rows && rows[0] && rows[0].data) || null;
    return { statusCode: 200, headers, body: JSON.stringify({ house }) };
  } catch (e) {
    return { statusCode: 200, headers, body: JSON.stringify({ house: null, error: String(e.message || e) }) };
  }
};
