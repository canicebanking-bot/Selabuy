const RESEND_API_KEY = process.env.RESEND_API_KEY || 're_dF8dTND4_N6XFGjC5RUQZq18BUGL2nvGe';

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const to = String(body.to || '').trim();
    const subject = String(body.subject || '').trim();
    const message = String(body.message || '').trim();
    const from = String(body.from || 'Sports Tech Gaming <noreply@sportstechgaming.com>').trim();

    if (!to || !subject || !message) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'to, subject and message required' }) };
    }
    if (!to.includes('@')) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'invalid email' }) };
    }

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + RESEND_API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from,
        to: [to],
        subject,
        html: '<div style="font-family:sans-serif;line-height:1.5;">' +
              message.replace(/\n/g, '<br>') +
              '</div>',
      }),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      return {
        statusCode: res.status,
        headers: cors,
        body: JSON.stringify({ error: data.message || data.error || 'Resend error', details: data }),
      };
    }

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({ ok: true, id: data.id }),
    };
  } catch (e) {
    return {
      statusCode: 500,
      headers: cors,
      body: JSON.stringify({ error: String(e.message || e) }),
    };
  }
};
