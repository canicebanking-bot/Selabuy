const { json, db, readSession } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405, { error: 'Method not allowed' });
  try {
    const session = readSession(event);
    if (!session) return json(401, { error: 'Please log in again.' });
    const limit = Math.min(200, Math.max(1, Number(event.queryStringParameters?.limit || 100)));
    const rows = await db(`dn_wallet_ledger?account_id=eq.${encodeURIComponent(session.sub)}&select=id,pool_id,position_id,entry_type,amount_ngn,balance_after_ngn,details,created_at&order=created_at.desc&limit=${limit}`);
    return json(200, { transactions: rows.map(r => ({ ...r, amount_ngn: Number(r.amount_ngn), balance_after_ngn: Number(r.balance_after_ngn) })) });
  } catch (e) {
    return json(500, { error: 'Could not load wallet history.' });
  }
};
