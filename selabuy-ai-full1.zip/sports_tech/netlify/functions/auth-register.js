const { json, db, hashPassword, issueSession, requireConfig } = require('./_shared');
exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });
  try {
    requireConfig();
    const body = JSON.parse(event.body || '{}');
    const username = String(body.username || '').trim();
    const password = String(body.password || '');
    const referralCode = String(body.referralCode || '').trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) return json(400, { error: 'Username must be 3–16 letters, numbers or underscores.' });
    if (password.length < 10 || password.length > 128) return json(400, { error: 'Password must be 10–128 characters.' });
    let referredBy = null;
    if (referralCode) {
      const rows = await db(`dn_accounts?username_norm=eq.${encodeURIComponent(referralCode.toLowerCase())}&select=id,username&limit=1`);
      if (!rows.length) return json(400, { error: 'Referral username not found.' });
      referredBy = rows[0].id;
    }
    const rows = await db('dn_accounts?select=id,username,username_norm', {
      method: 'POST', headers: { Prefer: 'return=representation' },
      body: JSON.stringify({ username, username_norm: username.toLowerCase(), password_hash: hashPassword(password), referred_by: referredBy }),
    });
    const account = rows[0];
    await db('dn_wallets', { method: 'POST', body: JSON.stringify({ account_id: account.id, balance_ngn: 0 }) });
    return json(201, { ok: true, username: account.username, token: issueSession(account), balance: 0 });
  } catch (e) {
    const msg = String(e.message || e);
    if (msg.includes('duplicate key')) return json(409, { error: 'Username is already taken.' });
    return json(500, { error: 'Registration failed. Please try again.' });
  }
};
