const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;

const cors = {
  'Content-Type': 'application/json',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: cors, body: '' };
  }
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  if (!PAYSTACK_SECRET) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: 'PAYSTACK_SECRET_KEY not configured on server' }) };
  }

  try {
    const body = JSON.parse(event.body || '{}');
    const reference = String(body.reference || '').trim();

    if (!reference) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: 'Reference required' }) };
    }

    const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET}`
      }
    });

    const data = await res.json();
    if (!res.ok || !data.status) {
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: data.message || 'Verification failed' }) };
    }

    const tx = data.data || {};
    const amountNaira = Math.round((tx.amount || 0) / 100);
    const success = tx.status === 'success';

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        success,
        amount: amountNaira,
        reference: tx.reference,
        status: tx.status,
        metadata: tx.metadata || {}
      })
    };
  } catch (err) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: err.message || 'Server error' }) };
  }
};
