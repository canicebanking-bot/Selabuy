# Sports Tech Gaming — test package (existing Supabase project)

## What is included

- The current Sports Tech Gaming frontend preview (`index.html`).
- A separate admin wallet test console at `/admin.html`.
- Server-side username/password auth endpoints for the new `dn_*` account system.
- Admin-only test account creation, username search, wallet credit/debit and transaction history. Quick-credit buttons now submit immediately (without a second confirmation), and the request-ID generator has a browser compatibility fallback.
- Authenticated `wallet-history` endpoint returning every wallet ledger movement, including stakes, prizes, referral earnings and admin adjustments.
- Atomic/idempotent wallet adjustment SQL: a transaction retry with the same request UUID cannot apply twice; debits cannot create a negative balance.
- Backend pool join and settlement RPCs with the agreed 90% winner / 7% house / 1% each referral-level allocation, tie splitting, and ledger entries. The final slot now triggers settlement synchronously from the join endpoint (with the scheduled worker retained as a retry/fallback).
- Existing legacy API function files retained so the preview frontend's current data calls do not immediately 404.

## Important scope limitation — read before uploading

This is a **test/staging package, not a finished production-money release**. The visible main website frontend still uses the old `/api/load-users`, `/api/save-user`, `/api/load-pools`, and `/api/save-pools` browser flow. It has NOT yet been migrated to the new `dn_*` account, wallet and pool APIs. Therefore:

- The admin console at `/admin.html` operates on the new `dn_*` test accounts and wallets only.
- It does not fund or deduct balances in the old `public.users` JSON records used by the current live frontend.
- A test account created in the admin console is not yet a login account for the current main website UI.
- The new pool APIs are included but the existing main frontend is not yet wired to them.
- The old legacy API functions remain in this package to keep the preview UI loading; they are not made secure by this package.

Do not use real users or real funds. Do not replace the live production site with this package yet.

## Step 1 — back up the existing Supabase project

In Supabase, create a project backup/export before changing anything. The migration creates new `dn_*` tables/functions and is designed to leave existing `users` and `app_state` tables alone, but take a backup first.

## Step 2 — apply the database migration

1. Open the existing Supabase project.
2. Open **SQL Editor** and create a new query.
3. Paste and run the complete file `supabase/migrations/001_secure_core.sql` (if you already applied it, do not rerun it just for this update).
4. Then run `supabase/migrations/002_immediate_payout_tie_and_referral_fix.sql` to update settlement and tie/referral allocation. This second migration is safe to run again.
5. Run `supabase/migrations/003_wallet_history_and_fast_admin.sql` to add the wallet-history indexes and idempotent admin-adjustment lock.
6. Confirm the new `dn_accounts`, `dn_wallets`, `dn_pools`, `dn_pool_positions`, `dn_wallet_ledger`, `dn_pool_results`, and `dn_house_ledger` tables exist.
7. Do not rerun the initial migration unnecessarily unless you have reviewed the SQL and checked the function definitions.

The migrations do not import existing legacy users. The `dn_*` account set starts empty.

## Step 3 — configure Netlify environment variables

In the Netlify test site's **Site configuration → Environment variables**, add:

- `SUPABASE_URL` — your existing Supabase project URL.
- `SUPABASE_SERVICE_ROLE_KEY` — the project's service-role/secret key. Keep it in Netlify only; never put it in HTML, JavaScript, chat, or Git.
- `SPORTSNAIRA_SESSION_SECRET` — a unique random secret of at least 32 characters. Example generation: `openssl rand -hex 32`.

Do not use the publishable/anon key for `SUPABASE_SERVICE_ROLE_KEY`. Redeploy after setting variables.

## Step 4 — create the first administrator

1. Register a dedicated administrator account using the new backend endpoint (after deploying):

   `POST /.netlify/functions/auth-register`

   JSON body: `{"username":"youradmin","password":"use-a-long-unique-password"}`

2. In Supabase SQL Editor, promote only that account (replace the username):

   `update public.dn_accounts set is_admin = true where username_norm = lower('youradmin');`

3. Verify exactly one row was updated. Do not promote ordinary users.
4. Open `https://YOUR-NETLIFY-TEST-SITE/admin.html` and sign in with that username/password.

## Step 5 — test wallet funding and deductions

1. In the admin console, create a test account with a username and temporary password.
2. Search for that username and select it.
3. Select the user and use the one-tap quick credit buttons (₦1,000 / ₦5,000 / ₦10,000 / ₦50,000), or enter a custom amount. Credit still asks for confirmation. Credit e.g. ₦5,000. Confirm the displayed balance becomes ₦5,000 and the ledger records `adjustment` with a positive amount.
4. Deduct e.g. ₦1,500. Confirm balance becomes ₦3,500 and ledger records a negative amount.
5. Try deducting ₦9,000. It should reject the request and leave the balance unchanged.
6. Repeat a transaction only by making a new explicit adjustment. The API uses a request UUID for idempotency so a network retry of one request cannot double-apply it.
7. Check the `dn_wallets` and `dn_wallet_ledger` tables in Supabase.

## Netlify deployment

Deploy this folder as a **separate Netlify test site**, not your production site. Upload the extracted folder containing `index.html`, `admin.html`, `netlify.toml`, `netlify/functions/`, and `supabase/`. Set environment variables and redeploy. The SQL migration is run in Supabase SQL Editor, not by Netlify.

## Backend endpoints included

- `POST /.netlify/functions/auth-register`
- `POST /.netlify/functions/auth-login`
- `GET /.netlify/functions/wallet-me`
- `GET /.netlify/functions/wallet-history?limit=100` (authenticated account ledger: stakes, prizes, referral commissions and adjustments)
- `POST /.netlify/functions/admin-create-test-user`
- `GET /.netlify/functions/admin-users?q=username` (admin session required)
- `POST /.netlify/functions/admin-adjust-wallet` (admin session required)
- `GET /.netlify/functions/admin-ledger?accountId=<uuid>` (admin session required)
- `POST /.netlify/functions/pool-join`
- `POST /.netlify/functions/pool-settle`
- `GET /.netlify/functions/pool-results?poolId=<uuid>`
- Scheduled `pool-settle-scheduled` function

## Checks performed in this package

Static JavaScript syntax and ZIP integrity checks are performed before delivery. The last slot now invokes the settlement RPC immediately rather than waiting for the next minute cron run. The cron worker remains as a retry/fallback. The payout RPC credits each winning position inside the same database transaction and publishes the stored result only after all wallet/ledger updates succeed. This environment cannot access your Supabase project or Netlify account, so the migration, environment variables, deployed functions, admin login, and database transactions still require testing in your test site. Do not treat static checks as live integration verification.

## History and frontend integration note

The new secure wallet ledger records pool stakes, winner payouts, referral commissions and admin adjustments. `GET /.netlify/functions/wallet-history` exposes those entries to the signed-in `dn_*` account. The legacy `index.html` still uses its original local/cloud JSON account model and is not yet migrated to the new `dn_*` authentication and wallet APIs. Therefore this endpoint and ledger are testable through the secure backend, but the existing legacy History screen will not automatically show these new ledger rows until that account/session integration is completed. Do not interpret the legacy UI history as a complete financial statement.
