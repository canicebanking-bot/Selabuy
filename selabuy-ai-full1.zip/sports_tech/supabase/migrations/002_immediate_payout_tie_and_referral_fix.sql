-- Dice Naira follow-up: accurate per-winning-slot tie/referral allocation.
-- Apply after 001_secure_core.sql. This replaces only the settlement RPC.
create or replace function public.dn_settle_pool(p_pool_id uuid, p_scores jsonb)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_pool dn_pools%rowtype;
  v_total bigint;
  v_win bigint;
  v_house bigint;
  v_ref_each bigint;
  v_ref_paid bigint;
  v_house_final bigint;
  v_top integer;
  v_winners uuid[];
  v_winner_count integer;
  v_row record;
  v_dice jsonb;
  v_score integer;
  v_share bigint;
  v_rem bigint;
  v_ref uuid;
  v_level integer;
  v_amount bigint;
  v_balance bigint;
  v_result jsonb;
  v_event text;
  v_ref_index integer;
begin
  select * into v_pool from dn_pools where id=p_pool_id for update;
  if not found then raise exception 'Pool not found'; end if;
  if v_pool.status='settled' then
    select result into v_result from dn_pool_results where pool_id=p_pool_id;
    return coalesce(v_result,'{}'::jsonb) || jsonb_build_object('duplicate',true);
  end if;
  if v_pool.status <> 'ready' then raise exception 'Pool is not ready'; end if;
  if jsonb_typeof(p_scores) <> 'array' then raise exception 'Invalid score payload'; end if;

  for v_row in select * from dn_pool_positions where pool_id=p_pool_id for update loop
    select value->'dice' into v_dice from jsonb_array_elements(p_scores) where value->>'position_id'=v_row.id::text;
    if v_dice is null or jsonb_array_length(v_dice) <> 3 then raise exception 'Missing dice result'; end if;
    if exists (select 1 from jsonb_array_elements_text(v_dice) d where d::int < 1 or d::int > 6) then raise exception 'Invalid dice'; end if;
    v_score := (v_dice->>0)::int + (v_dice->>1)::int + (v_dice->>2)::int;
    update dn_pool_positions set dice=v_dice, score=v_score where id=v_row.id;
  end loop;

  select sum(stake_ngn), max(score) into v_total,v_top from dn_pool_positions where pool_id=p_pool_id;
  select array_agg(distinct account_id order by account_id), count(*) into v_winners,v_winner_count
    from dn_pool_positions where pool_id=p_pool_id and score=v_top;
  if v_winner_count is null or v_winner_count=0 then raise exception 'No winner'; end if;

  v_win := floor(v_total * 0.90);
  v_house := floor(v_total * 0.07);
  v_ref_each := floor(v_total * 0.01);
  -- Rounding remainder and any missing referral levels accrue to the house.
  v_house_final := v_total - v_win - v_house - (3*v_ref_each);
  v_share := floor(v_win / v_winner_count);
  v_rem := v_win - (v_share*v_winner_count);

  for v_row in select p.*, a.username from dn_pool_positions p join dn_accounts a on a.id=p.account_id
    where p.pool_id=p_pool_id and p.score=v_top order by p.created_at,p.id loop
    v_amount := v_share;
    if v_rem > 0 then v_amount := v_amount + 1; v_rem := v_rem - 1; end if;
    update dn_wallets set balance_ngn=balance_ngn+v_amount,updated_at=now()
      where account_id=v_row.account_id returning balance_ngn into v_balance;
    insert into dn_wallet_ledger(account_id,pool_id,position_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
    values(v_row.account_id,p_pool_id,v_row.id,'prize:'||p_pool_id::text||':'||v_row.id::text,'pool_prize',v_amount,v_balance,
      jsonb_build_object('score',v_top,'tie_count',v_winner_count));
  end loop;

  -- Allocate each referral-level 1% share per winning position (not merely
  -- per distinct username), so multiple winning slots and tied slots are handled
  -- consistently. Integer remainders go to the earliest winning positions.
  -- Missing/inactive referral wallets are redirected to the house.
  for v_level in 1..3 loop
    v_ref_paid := 0;
    v_ref_index := 0;
    for v_row in select p.id as position_id, p.account_id
      from dn_pool_positions p where p.pool_id=p_pool_id and p.score=v_top
      order by p.created_at,p.id loop
      v_ref_index := v_ref_index + 1;
      select referred_by into v_ref from dn_accounts where id=v_row.account_id;
      if v_level > 1 and v_ref is not null then
        select referred_by into v_ref from dn_accounts where id=v_ref;
      end if;
      if v_level > 2 and v_ref is not null then
        select referred_by into v_ref from dn_accounts where id=v_ref;
      end if;
      v_amount := floor(v_ref_each / v_winner_count);
      if v_ref_index <= mod(v_ref_each, v_winner_count) then
        v_amount := v_amount + 1;
      end if;
      if v_ref is not null and v_amount > 0 then
        update dn_wallets set balance_ngn=balance_ngn+v_amount,updated_at=now()
          where account_id=v_ref returning balance_ngn into v_balance;
        if found then
          insert into dn_wallet_ledger(account_id,pool_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
          values(v_ref,p_pool_id,'ref:'||p_pool_id::text||':'||v_level||':'||v_row.position_id::text,'referral_commission',v_amount,v_balance,
            jsonb_build_object('level',v_level,'winning_position_id',v_row.position_id));
          v_ref_paid := v_ref_paid + v_amount;
        end if;
      end if;
    end loop;
    v_house_final := v_house_final + (v_ref_each - v_ref_paid);
  end loop;

  insert into dn_house_ledger(pool_id,event_key,amount_ngn)
    values(p_pool_id,'house:'||p_pool_id::text,v_house_final);
  v_result := jsonb_build_object('pool_id',p_pool_id,'tier',v_pool.tier,'total_collected_ngn',v_total,
    'winner_total_ngn',v_win,'house_total_ngn',v_house_final,'referral_rate_each',0.01,
    'winning_score',v_top,'winner_account_ids',to_jsonb(v_winners),'tie_count',v_winner_count,'winner_position_count',v_winner_count,'settled_at',now());
  update dn_pools set status='settled',settled_at=now(),total_collected_ngn=v_total,
    winner_total_ngn=v_win,house_total_ngn=v_house_final,result=v_result where id=p_pool_id;
  insert into dn_pool_results(pool_id,result) values(p_pool_id,v_result);
  return v_result;
end; $$;

revoke all on function public.dn_settle_pool(uuid,jsonb) from public, anon, authenticated;
grant execute on function public.dn_settle_pool(uuid,jsonb) to service_role;
