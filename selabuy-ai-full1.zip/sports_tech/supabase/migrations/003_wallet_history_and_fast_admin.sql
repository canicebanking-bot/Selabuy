-- Dice Naira: wallet history indexes and settlement safeguards.
-- Apply after migrations 001 and 002. Safe to run more than once.
create index if not exists dn_ledger_account_created_idx
  on public.dn_wallet_ledger(account_id, created_at desc, id desc);
create index if not exists dn_ledger_pool_idx
  on public.dn_wallet_ledger(pool_id, entry_type, created_at desc)
  where pool_id is not null;

-- The ledger is the source of truth for every wallet movement:
-- pool_stake is negative; pool_prize/referral_commission/admin credit are positive;
-- admin debit is negative. This view is server-only through service_role.
create or replace view public.dn_wallet_history as
select id, account_id, pool_id, position_id, entry_type, amount_ngn,
       balance_after_ngn, details, created_at
from public.dn_wallet_ledger;
revoke all on public.dn_wallet_history from public, anon, authenticated;
grant select on public.dn_wallet_history to service_role;

-- Serialize duplicate admin request IDs before checking the ledger. This makes
-- a retry return the original successful result instead of racing a unique key.
create or replace function public.dn_admin_adjust_wallet(
  p_account_id uuid,
  p_admin_id uuid,
  p_amount_ngn bigint,
  p_action text,
  p_reason text,
  p_request_id uuid
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_admin boolean;
  v_balance bigint;
  v_delta bigint;
  v_event text;
  v_ledger_id uuid;
  v_existing dn_wallet_ledger%rowtype;
begin
  if p_action not in ('credit','debit') then raise exception 'Action must be credit or debit'; end if;
  if p_amount_ngn is null or p_amount_ngn <= 0 or p_amount_ngn > 1000000000 then raise exception 'Amount is outside allowed range'; end if;
  if length(trim(coalesce(p_reason,''))) < 3 or length(p_reason) > 240 then raise exception 'Enter a reason between 3 and 240 characters'; end if;
  select is_admin into v_admin from dn_accounts where id=p_admin_id and is_active=true;
  if coalesce(v_admin,false) is not true then raise exception 'Admin authorization required'; end if;
  v_event := 'admin-adjust:' || p_request_id::text;
  perform pg_advisory_xact_lock(hashtextextended(v_event, 0));
  select * into v_existing from dn_wallet_ledger where event_key=v_event;
  if found then
    return jsonb_build_object('ok',true,'duplicate',true,'balance_ngn',v_existing.balance_after_ngn,'ledger_id',v_existing.id);
  end if;
  v_delta := case when p_action='credit' then p_amount_ngn else -p_amount_ngn end;
  select balance_ngn into v_balance from dn_wallets where account_id=p_account_id for update;
  if not found then raise exception 'Wallet not found'; end if;
  if v_balance + v_delta < 0 then raise exception 'Insufficient balance for this deduction'; end if;
  update dn_wallets set balance_ngn=balance_ngn+v_delta, updated_at=now()
    where account_id=p_account_id returning balance_ngn into v_balance;
  insert into dn_wallet_ledger(account_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
  values(p_account_id,v_event,'adjustment',v_delta,v_balance,
    jsonb_build_object('action',p_action,'reason',trim(p_reason),'admin_id',p_admin_id,'admin_username',(select username from dn_accounts where id=p_admin_id)))
  returning id into v_ledger_id;
  return jsonb_build_object('ok',true,'duplicate',false,'balance_ngn',v_balance,'ledger_id',v_ledger_id);
end; $$;
revoke all on function public.dn_admin_adjust_wallet(uuid,uuid,bigint,text,text,uuid) from public, anon, authenticated;
grant execute on function public.dn_admin_adjust_wallet(uuid,uuid,bigint,text,text,uuid) to service_role;
