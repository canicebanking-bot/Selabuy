-- Dice Naira secure core schema. Apply to a NEW/empty Supabase project only.
-- Existing public.users and public.app_state are deliberately not modified.
create extension if not exists pgcrypto;

create table if not exists public.dn_accounts (
  id uuid primary key default gen_random_uuid(),
  username text not null,
  username_norm text not null unique,
  password_hash text not null,
  referred_by uuid references public.dn_accounts(id),
  created_at timestamptz not null default now(),
  is_admin boolean not null default false,
  is_active boolean not null default true,
  constraint dn_username_format check (username ~ '^[A-Za-z0-9_]{3,16}$'),
  constraint dn_no_self_referral check (referred_by is null or referred_by <> id)
);

create table if not exists public.dn_wallets (
  account_id uuid primary key references public.dn_accounts(id) on delete cascade,
  balance_ngn bigint not null default 0 check (balance_ngn >= 0),
  updated_at timestamptz not null default now()
);

create table if not exists public.dn_pools (
  id uuid primary key default gen_random_uuid(),
  tier text not null check (tier in ('5x','10x','50x')),
  entry_ngn bigint not null check (entry_ngn > 0),
  capacity integer not null check (capacity in (5,10,50)),
  status text not null default 'open' check (status in ('open','ready','settled','cancelled')),
  created_at timestamptz not null default now(),
  settled_at timestamptz,
  total_collected_ngn bigint,
  winner_total_ngn bigint,
  house_total_ngn bigint,
  result jsonb
);

create index if not exists dn_pools_open_idx on public.dn_pools(tier, entry_ngn, created_at) where status = 'open';

create table if not exists public.dn_pool_positions (
  id uuid primary key default gen_random_uuid(),
  pool_id uuid not null references public.dn_pools(id) on delete restrict,
  account_id uuid not null references public.dn_accounts(id) on delete restrict,
  position_no integer not null,
  stake_ngn bigint not null check (stake_ngn > 0),
  dice jsonb,
  score integer check (score between 3 and 18),
  created_at timestamptz not null default now(),
  unique(pool_id, position_no)
);
create index if not exists dn_positions_account_idx on public.dn_pool_positions(account_id, created_at desc);

create table if not exists public.dn_wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  account_id uuid not null references public.dn_accounts(id),
  pool_id uuid references public.dn_pools(id),
  position_id uuid references public.dn_pool_positions(id),
  event_key text not null unique,
  entry_type text not null check (entry_type in ('pool_stake','pool_prize','referral_commission','house_commission','adjustment')),
  amount_ngn bigint not null,
  balance_after_ngn bigint not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists dn_ledger_account_idx on public.dn_wallet_ledger(account_id, created_at desc);

create table if not exists public.dn_pool_results (
  pool_id uuid primary key references public.dn_pools(id),
  result jsonb not null,
  published_at timestamptz not null default now()
);

create table if not exists public.dn_house_ledger (
  id uuid primary key default gen_random_uuid(),
  pool_id uuid not null references public.dn_pools(id),
  event_key text not null unique,
  amount_ngn bigint not null check (amount_ngn >= 0),
  created_at timestamptz not null default now()
);

-- No browser role may read/write private account, wallet, position, or ledger rows.
alter table public.dn_accounts enable row level security;
alter table public.dn_wallets enable row level security;
alter table public.dn_pools enable row level security;
alter table public.dn_pool_positions enable row level security;
alter table public.dn_wallet_ledger enable row level security;
alter table public.dn_pool_results enable row level security;
alter table public.dn_house_ledger enable row level security;

revoke all on public.dn_accounts, public.dn_wallets, public.dn_pools,
  public.dn_pool_positions, public.dn_wallet_ledger, public.dn_pool_results,
  public.dn_house_ledger from anon, authenticated;
grant all on public.dn_accounts, public.dn_wallets, public.dn_pools,
  public.dn_pool_positions, public.dn_wallet_ledger, public.dn_pool_results,
  public.dn_house_ledger to service_role;

-- Atomically lock one position. The caller must authenticate the user and call
-- this RPC with the corresponding account UUID. Advisory lock serializes joins
-- for the same tier/entry; row locks protect balances and pool state.
create or replace function public.dn_join_pool(
  p_account_id uuid,
  p_tier text,
  p_entry_ngn bigint,
  p_request_id uuid
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_capacity integer;
  v_pool public.dn_pools%rowtype;
  v_balance bigint;
  v_position_id uuid;
  v_count integer;
  v_user_positions integer;
begin
  if p_tier not in ('5x','10x','50x') or p_entry_ngn <= 0 then
    raise exception 'Invalid pool tier or entry amount';
  end if;
  v_capacity := case p_tier when '5x' then 5 when '10x' then 10 else 50 end;
  perform pg_advisory_xact_lock(hashtextextended(p_tier || ':' || p_entry_ngn::text, 0));

  if exists (select 1 from dn_wallet_ledger where event_key = 'stake:' || p_request_id::text) then
    return jsonb_build_object('ok', true, 'duplicate', true);
  end if;

  select balance_ngn into v_balance from dn_wallets where account_id = p_account_id for update;
  if not found then raise exception 'Wallet not found'; end if;
  if v_balance < p_entry_ngn then raise exception 'Insufficient wallet balance'; end if;

  select * into v_pool from dn_pools
   where tier = p_tier and entry_ngn = p_entry_ngn and status = 'open'
   order by created_at asc limit 1 for update;
  if not found then
    insert into dn_pools(tier, entry_ngn, capacity)
    values (p_tier, p_entry_ngn, v_capacity) returning * into v_pool;
  end if;

  select count(*) into v_count from dn_pool_positions where pool_id = v_pool.id;
  if v_count >= v_capacity then raise exception 'Pool is full'; end if;
  select count(*) into v_user_positions from dn_pool_positions
   where pool_id = v_pool.id and account_id = p_account_id;
  if v_user_positions >= case p_tier when '5x' then 1 when '10x' then 5 else 10 end then
    raise exception 'Maximum positions reached for this pool';
  end if;

  update dn_wallets set balance_ngn = balance_ngn - p_entry_ngn, updated_at = now()
   where account_id = p_account_id returning balance_ngn into v_balance;
  insert into dn_pool_positions(pool_id, account_id, position_no, stake_ngn)
  values (v_pool.id, p_account_id, v_count + 1, p_entry_ngn) returning id into v_position_id;
  insert into dn_wallet_ledger(account_id,pool_id,position_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
  values (p_account_id,v_pool.id,v_position_id,'stake:'||p_request_id::text,'pool_stake',-p_entry_ngn,v_balance,
    jsonb_build_object('tier',p_tier,'entry_ngn',p_entry_ngn));
  v_count := v_count + 1;
  if v_count = v_capacity then update dn_pools set status = 'ready' where id = v_pool.id; end if;
  return jsonb_build_object('ok',true,'pool_id',v_pool.id,'position_id',v_position_id,
    'position_no',v_count,'pool_count',v_count,'capacity',v_capacity,'status',case when v_count=v_capacity then 'ready' else 'open' end,
    'balance_ngn',v_balance);
end; $$;

-- Settlement is idempotent and performed in one database transaction.
-- p_scores must contain [{"position_id":"uuid","dice":[1,2,3]}] for every position.
create or replace function public.dn_settle_pool(p_pool_id uuid, p_scores jsonb)
returns jsonb language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_pool dn_pools%rowtype;
  v_total bigint;
  v_win bigint;
  v_house bigint;
  v_ref_each bigint;
  v_ref_paid bigint;
  v_house_final bigint;
  v_top integer;
  v_winners uuid[];
  v_winner_count integer;
  v_row record;
  v_dice jsonb;
  v_score integer;
  v_share bigint;
  v_rem bigint;
  v_ref uuid;
  v_level integer;
  v_amount bigint;
  v_balance bigint;
  v_result jsonb;
  v_event text;
begin
  select * into v_pool from dn_pools where id=p_pool_id for update;
  if not found then raise exception 'Pool not found'; end if;
  if v_pool.status='settled' then
    select result into v_result from dn_pool_results where pool_id=p_pool_id;
    return coalesce(v_result,'{}'::jsonb) || jsonb_build_object('duplicate',true);
  end if;
  if v_pool.status <> 'ready' then raise exception 'Pool is not ready'; end if;
  if jsonb_typeof(p_scores) <> 'array' then raise exception 'Invalid score payload'; end if;

  for v_row in select * from dn_pool_positions where pool_id=p_pool_id for update loop
    select value->'dice' into v_dice from jsonb_array_elements(p_scores) where value->>'position_id'=v_row.id::text;
    if v_dice is null or jsonb_array_length(v_dice) <> 3 then raise exception 'Missing dice result'; end if;
    if exists (select 1 from jsonb_array_elements_text(v_dice) d where d::int < 1 or d::int > 6) then raise exception 'Invalid dice'; end if;
    v_score := (v_dice->>0)::int + (v_dice->>1)::int + (v_dice->>2)::int;
    update dn_pool_positions set dice=v_dice, score=v_score where id=v_row.id;
  end loop;

  select sum(stake_ngn), max(score) into v_total,v_top from dn_pool_positions where pool_id=p_pool_id;
  select array_agg(account_id order by account_id), count(*) into v_winners,v_winner_count
    from dn_pool_positions where pool_id=p_pool_id and score=v_top;
  if v_winner_count is null or v_winner_count=0 then raise exception 'No winner'; end if;

  v_win := floor(v_total * 0.90);
  v_house := floor(v_total * 0.07);
  v_ref_each := floor(v_total * 0.01);
  -- Rounding remainder and any missing referral levels accrue to the house.
  v_house_final := v_total - v_win - v_house - (3*v_ref_each);
  v_share := floor(v_win / v_winner_count);
  v_rem := v_win - (v_share*v_winner_count);

  for v_row in select p.*, a.username from dn_pool_positions p join dn_accounts a on a.id=p.account_id
    where p.pool_id=p_pool_id and p.score=v_top order by p.created_at,p.id loop
    v_amount := v_share;
    if v_rem > 0 then v_amount := v_amount + 1; v_rem := v_rem - 1; end if;
    update dn_wallets set balance_ngn=balance_ngn+v_amount,updated_at=now()
      where account_id=v_row.account_id returning balance_ngn into v_balance;
    insert into dn_wallet_ledger(account_id,pool_id,position_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
    values(v_row.account_id,p_pool_id,v_row.id,'prize:'||p_pool_id::text||':'||v_row.id::text,'pool_prize',v_amount,v_balance,
      jsonb_build_object('score',v_top,'tie_count',v_winner_count));
  end loop;

  -- Commission per referral level is distributed across winning accounts' upline.
  -- Missing upline shares are redirected to house. Per-winner fractional remainders
  -- are retained by house to keep the pool exactly balanced.
  for v_level in 1..3 loop
    v_ref_paid := 0;
    for v_row in select distinct account_id from dn_pool_positions where pool_id=p_pool_id and score=v_top loop
      select referred_by into v_ref from dn_accounts where id=v_row.account_id;
      if v_level > 1 and v_ref is not null then
        select referred_by into v_ref from dn_accounts where id=v_ref;
      end if;
      if v_level > 2 and v_ref is not null then
        select referred_by into v_ref from dn_accounts where id=v_ref;
      end if;
      if v_ref is not null then
        v_amount := floor(v_ref_each / v_winner_count);
        if v_amount > 0 then
          update dn_wallets set balance_ngn=balance_ngn+v_amount,updated_at=now()
            where account_id=v_ref returning balance_ngn into v_balance;
          if found then
            insert into dn_wallet_ledger(account_id,pool_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
            values(v_ref,p_pool_id,'ref:'||p_pool_id::text||':'||v_level||':'||v_row.account_id::text,'referral_commission',v_amount,v_balance,
              jsonb_build_object('level',v_level));
            v_ref_paid := v_ref_paid + v_amount;
          end if;
        end if;
      end if;
    end loop;
    v_house_final := v_house_final + (v_ref_each - v_ref_paid);
  end loop;

  insert into dn_house_ledger(pool_id,event_key,amount_ngn)
    values(p_pool_id,'house:'||p_pool_id::text,v_house_final);
  v_result := jsonb_build_object('pool_id',p_pool_id,'tier',v_pool.tier,'total_collected_ngn',v_total,
    'winner_total_ngn',v_win,'house_total_ngn',v_house_final,'referral_rate_each',0.01,
    'winning_score',v_top,'winner_account_ids',to_jsonb(v_winners),'tie_count',v_winner_count,'settled_at',now());
  update dn_pools set status='settled',settled_at=now(),total_collected_ngn=v_total,
    winner_total_ngn=v_win,house_total_ngn=v_house_final,result=v_result where id=p_pool_id;
  insert into dn_pool_results(pool_id,result) values(p_pool_id,v_result);
  return v_result;
end; $$;

revoke all on function public.dn_join_pool(uuid,text,bigint,uuid) from public, anon, authenticated;
revoke all on function public.dn_settle_pool(uuid,jsonb) from public, anon, authenticated;
grant execute on function public.dn_join_pool(uuid,text,bigint,uuid) to service_role;
grant execute on function public.dn_settle_pool(uuid,jsonb) to service_role;

-- Admin wallet adjustments: all balance changes are atomic and idempotent.
create or replace function public.dn_admin_adjust_wallet(
  p_account_id uuid,
  p_admin_id uuid,
  p_amount_ngn bigint,
  p_action text,
  p_reason text,
  p_request_id uuid
) returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $$
declare
  v_admin boolean;
  v_balance bigint;
  v_delta bigint;
  v_event text;
  v_ledger_id uuid;
  v_existing dn_wallet_ledger%rowtype;
begin
  if p_action not in ('credit','debit') then raise exception 'Action must be credit or debit'; end if;
  if p_amount_ngn <= 0 or p_amount_ngn > 1000000000 then raise exception 'Amount is outside allowed range'; end if;
  if length(trim(coalesce(p_reason,''))) < 3 or length(p_reason) > 240 then raise exception 'Enter a reason between 3 and 240 characters'; end if;
  select is_admin into v_admin from dn_accounts where id=p_admin_id and is_active=true;
  if coalesce(v_admin,false) is not true then raise exception 'Admin authorization required'; end if;
  v_event := 'admin-adjust:' || p_request_id::text;
  select * into v_existing from dn_wallet_ledger where event_key=v_event;
  if found then
    return jsonb_build_object('ok',true,'duplicate',true,'balance_ngn',v_existing.balance_after_ngn,'ledger_id',v_existing.id);
  end if;
  v_delta := case when p_action='credit' then p_amount_ngn else -p_amount_ngn end;
  select balance_ngn into v_balance from dn_wallets where account_id=p_account_id for update;
  if not found then raise exception 'Wallet not found'; end if;
  if v_balance + v_delta < 0 then raise exception 'Insufficient balance for this deduction'; end if;
  update dn_wallets set balance_ngn=balance_ngn+v_delta, updated_at=now()
    where account_id=p_account_id returning balance_ngn into v_balance;
  insert into dn_wallet_ledger(account_id,event_key,entry_type,amount_ngn,balance_after_ngn,details)
  values(p_account_id,v_event,'adjustment',v_delta,v_balance,
    jsonb_build_object('action',p_action,'reason',trim(p_reason),'admin_id',p_admin_id,'admin_username',(select username from dn_accounts where id=p_admin_id)))
  returning id into v_ledger_id;
  return jsonb_build_object('ok',true,'duplicate',false,'balance_ngn',v_balance,'ledger_id',v_ledger_id);
end; $$;
revoke all on function public.dn_admin_adjust_wallet(uuid,uuid,bigint,text,text,uuid) from public, anon, authenticated;
grant execute on function public.dn_admin_adjust_wallet(uuid,uuid,bigint,text,text,uuid) to service_role;
